"use client"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ExternalLink, Github, Star, Eye, Code } from "lucide-react"

const projects = [
  {
    title: "FoodAI – AI-Powered Food Delivery Platform",
    description:
      "Revolutionary food delivery platform with AI-powered recommendations, smart meal suggestions, and personalized dining experiences using machine learning algorithms.",
    image: "/ai-food-delivery-app-interface.jpg",
    tech: ["React", "Node.js", "MongoDB", "OpenAI API", "Machine Learning", "Express.js", "JWT Auth"],
    skills: {
      frontend: ["React", "JavaScript", "CSS3", "Responsive Design"],
      backend: ["Node.js", "Express.js", "RESTful APIs"],
      database: ["MongoDB", "Mongoose"],
      ai: ["OpenAI API", "Machine Learning", "Natural Language Processing"],
      tools: ["Git", "Netlify", "Postman"],
    },
    liveDemo: "https://glittery-hamster-98e93b.netlify.app",
    github: "#",
    featured: true,
    stats: { views: "2.5K", stars: "45", forks: "12" },
  },
  {
    title: "CityVerse X - Smart City Simulation",
    description:
      "Futuristic 3D smart city simulation featuring IoT integration, traffic management, urban planning solutions, and real-time data visualization.",
    image: "/3d-smart-city-simulation-interface.jpg",
    tech: ["Three.js", "React", "WebGL", "IoT", "AI", "PostgreSQL", "Socket.io"],
    skills: {
      frontend: ["React", "Three.js", "WebGL", "JavaScript", "CSS3"],
      backend: ["Node.js", "Socket.io", "Real-time Data"],
      database: ["PostgreSQL", "Time-series Data"],
      ai: ["AI Algorithms", "Data Analytics", "Predictive Modeling"],
      tools: ["Blender", "Git", "Docker", "Lovable"],
    },
    liveDemo: "https://cityverse-x-design.lovable.app",
    github: "#",
    featured: true,
    stats: { views: "3.2K", stars: "67", forks: "23" },
  },
  {
    title: "Netflix Clone - Binge Bliss Theater",
    description:
      "Full-featured streaming platform replica with user authentication, movie browsing, search functionality, and responsive design mimicking Netflix's interface.",
    image: "/netflix-clone-streaming-interface.jpg",
    tech: ["React", "Firebase", "TMDB API", "CSS3", "Authentication", "Responsive Design"],
    skills: {
      frontend: ["React", "JavaScript", "CSS3", "Responsive Design", "Material-UI"],
      backend: ["Firebase", "Cloud Functions", "RESTful APIs"],
      database: ["Firebase Firestore", "Real-time Database"],
      auth: ["Firebase Auth", "JWT", "OAuth"],
      tools: ["Git", "Lovable", "TMDB API", "Figma"],
    },
    liveDemo: "https://binge-bliss-theater.lovable.app",
    github: "#",
    featured: true,
    stats: { views: "4.1K", stars: "89", forks: "34" },
  },
  {
    title: "TravelSync - Corporate Travel Optimizer",
    description:
      "Intelligent corporate travel management system with AI-powered itinerary optimization, expense tracking, and seamless team coordination features.",
    image: "/corporate-travel-management-dashboard.jpg",
    tech: ["React", "Node.js", "PostgreSQL", "AI/ML", "Travel APIs", "Chart.js"],
    skills: {
      frontend: ["React", "TypeScript", "Chart.js", "Material-UI"],
      backend: ["Node.js", "Express.js", "RESTful APIs", "Microservices"],
      database: ["PostgreSQL", "Redis", "Data Modeling"],
      ai: ["Machine Learning", "Optimization Algorithms", "Data Analytics"],
      tools: ["Git", "Netlify", "Travel APIs", "Docker"],
    },
    liveDemo: "https://kaleidoscopic-centaur-560970.netlify.app",
    github: "#",
    stats: { views: "1.8K", stars: "32", forks: "8" },
  },
  {
    title: "Forest Fire Prediction System",
    description:
      "Advanced AI-powered system using machine learning algorithms to predict forest fire risks based on environmental data, weather patterns, and historical analysis.",
    image: "/forest-fire-prediction-ai-system-dashboard.jpg",
    tech: ["Python", "Machine Learning", "Pandas", "Scikit-learn", "Data Analysis", "Flask"],
    skills: {
      frontend: ["HTML5", "CSS3", "JavaScript", "Bootstrap"],
      backend: ["Python", "Flask", "RESTful APIs"],
      ml: ["Scikit-learn", "Pandas", "NumPy", "Matplotlib", "Data Preprocessing"],
      data: ["Data Analysis", "Feature Engineering", "Model Training", "Statistical Analysis"],
      tools: ["Jupyter Notebook", "Git", "Netlify", "Weather APIs"],
    },
    liveDemo: "https://animated-cendol-930ab4.netlify.app",
    github: "#",
    stats: { views: "2.9K", stars: "56", forks: "19" },
  },
  {
    title: "AI Fake News Detector",
    description:
      "Sophisticated Natural Language Processing application that analyzes news articles and social media posts to detect misinformation and fake news with high accuracy.",
    image: "/ai-fake-news-detection-interface.jpg",
    tech: ["Python", "NLP", "TensorFlow", "React", "Machine Learning", "BERT"],
    skills: {
      frontend: ["React", "JavaScript", "CSS3", "Material-UI"],
      backend: ["Python", "Flask", "TensorFlow", "RESTful APIs"],
      ml: ["Natural Language Processing", "TensorFlow", "BERT", "Text Classification"],
      data: ["Data Preprocessing", "Feature Extraction", "Model Training", "Accuracy Optimization"],
      tools: ["Jupyter Notebook", "Git", "Netlify", "News APIs"],
    },
    liveDemo: "https://fabulous-cascaron-7fecc7.netlify.app",
    github: "#",
    stats: { views: "3.7K", stars: "78", forks: "28" },
  },
  {
    title: "E-commerce Website",
    description:
      "Comprehensive full-stack e-commerce platform featuring user authentication, product catalog, shopping cart, payment integration, and admin dashboard.",
    image: "/modern-ecommerce-interface.png",
    tech: ["React", "Node.js", "MongoDB", "Express", "Payment Gateway", "Redux"],
    skills: {
      frontend: ["React", "Redux", "JavaScript", "CSS3", "Bootstrap"],
      backend: ["Node.js", "Express.js", "RESTful APIs", "Middleware"],
      database: ["MongoDB", "Mongoose", "Database Design"],
      payment: ["Stripe API", "PayPal Integration", "Secure Transactions"],
      tools: ["Git", "Netlify", "Postman", "MongoDB Atlas"],
    },
    liveDemo: "https://kaleidoscopic-rugelach-018c9f.netlify.app",
    github: "#",
    stats: { views: "5.2K", stars: "123", forks: "45" },
  },
]

export function ProjectsSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const [filter, setFilter] = useState<"all" | "featured">("all")

  const filteredProjects = filter === "featured" ? projects.filter((project) => project.featured) : projects

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section id="projects" ref={sectionRef} className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4 text-gradient">Featured Projects</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            Showcasing innovative solutions that blend cutting-edge technology with exceptional user experiences
          </p>

          <div className="flex justify-center gap-4 mb-8">
            <Button
              variant={filter === "all" ? "default" : "outline"}
              onClick={() => setFilter("all")}
              className="glassmorphism border-border/50"
            >
              <Code className="h-4 w-4 mr-2" />
              All Projects ({projects.length})
            </Button>
            <Button
              variant={filter === "featured" ? "default" : "outline"}
              onClick={() => setFilter("featured")}
              className="glassmorphism border-border/50"
            >
              <Star className="h-4 w-4 mr-2" />
              Featured ({projects.filter((p) => p.featured).length})
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <Card
              key={project.title}
              className={`glassmorphism border-border/50 overflow-hidden hover:neon-glow transition-all duration-300 hover:scale-105 group relative ${
                project.featured ? "ring-2 ring-primary/20" : ""
              }`}
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {project.featured && (
                <div className="absolute top-4 right-4 z-10">
                  <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white border-0">
                    <Star className="h-3 w-3 mr-1" />
                    Featured
                  </Badge>
                </div>
              )}

              <div className="relative overflow-hidden">
                <img
                  src={project.image || "/placeholder.svg"}
                  alt={project.title}
                  className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                <div className="absolute bottom-2 left-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <Badge variant="secondary" className="text-xs glassmorphism border-border/50">
                    <Eye className="h-3 w-3 mr-1" />
                    {project.stats.views}
                  </Badge>
                  <Badge variant="secondary" className="text-xs glassmorphism border-border/50">
                    <Star className="h-3 w-3 mr-1" />
                    {project.stats.stars}
                  </Badge>
                </div>
              </div>

              <CardHeader>
                <CardTitle className="text-xl text-primary group-hover:text-gradient transition-all duration-300">
                  {project.title}
                </CardTitle>
                <CardDescription className="text-muted-foreground line-clamp-3">{project.description}</CardDescription>
              </CardHeader>

              <CardContent>
                <div className="mb-4">
                  <div className="flex flex-wrap gap-2 mb-3">
                    {project.tech.map((tech) => (
                      <Badge
                        key={tech}
                        variant="secondary"
                        className="text-xs glassmorphism border-border/50 hover:border-primary/50 transition-colors duration-300 hover:scale-105"
                      >
                        {tech}
                      </Badge>
                    ))}
                  </div>

                  <div className="space-y-2 text-xs">
                    {project.skills.frontend && (
                      <div className="flex items-center gap-2">
                        <span className="text-blue-400 font-medium min-w-[60px]">Frontend:</span>
                        <div className="flex flex-wrap gap-1">
                          {project.skills.frontend.map((skill) => (
                            <Badge
                              key={skill}
                              variant="outline"
                              className="text-[10px] px-1 py-0 h-5 border-blue-400/30 text-blue-400"
                            >
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {project.skills.backend && (
                      <div className="flex items-center gap-2">
                        <span className="text-green-400 font-medium min-w-[60px]">Backend:</span>
                        <div className="flex flex-wrap gap-1">
                          {project.skills.backend.map((skill) => (
                            <Badge
                              key={skill}
                              variant="outline"
                              className="text-[10px] px-1 py-0 h-5 border-green-400/30 text-green-400"
                            >
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {(project.skills.database || project.skills.data) && (
                      <div className="flex items-center gap-2">
                        <span className="text-purple-400 font-medium min-w-[60px]">Data:</span>
                        <div className="flex flex-wrap gap-1">
                          {(project.skills.database || project.skills.data || []).map((skill) => (
                            <Badge
                              key={skill}
                              variant="outline"
                              className="text-[10px] px-1 py-0 h-5 border-purple-400/30 text-purple-400"
                            >
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}

                    {(project.skills.ai || project.skills.ml) && (
                      <div className="flex items-center gap-2">
                        <span className="text-orange-400 font-medium min-w-[60px]">AI/ML:</span>
                        <div className="flex flex-wrap gap-1">
                          {(project.skills.ai || project.skills.ml || []).map((skill) => (
                            <Badge
                              key={skill}
                              variant="outline"
                              className="text-[10px] px-1 py-0 h-5 border-orange-400/30 text-orange-400"
                            >
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    size="sm"
                    className="flex-1 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 text-primary-foreground border-0 group/btn"
                    asChild
                  >
                    <a href={project.liveDemo} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-4 w-4 mr-2 group-hover/btn:rotate-12 transition-transform duration-300" />
                      Live Demo
                    </a>
                  </Button>

                  <Button
                    variant="outline"
                    size="sm"
                    className="glassmorphism border-border/50 bg-transparent hover:bg-primary/10 group/btn"
                    asChild
                  >
                    <a href={project.github} target="_blank" rel="noopener noreferrer">
                      <Github className="h-4 w-4 group-hover/btn:rotate-12 transition-transform duration-300" />
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-2xl mx-auto">
            <div className="glassmorphism border-border/50 p-6 rounded-lg">
              <div className="text-3xl font-bold text-gradient mb-2">{projects.length}+</div>
              <div className="text-muted-foreground">Projects Built</div>
            </div>
            <div className="glassmorphism border-border/50 p-6 rounded-lg">
              <div className="text-3xl font-bold text-gradient mb-2">
                {projects.reduce(
                  (total, project) => total + Number.parseInt(project.stats.views.replace("K", "00").replace(".", "")),
                  0,
                ) / 100}
                K+
              </div>
              <div className="text-muted-foreground">Total Views</div>
            </div>
            <div className="glassmorphism border-border/50 p-6 rounded-lg">
              <div className="text-3xl font-bold text-gradient mb-2">
                {projects.reduce((total, project) => total + Number.parseInt(project.stats.stars), 0)}+
              </div>
              <div className="text-muted-foreground">GitHub Stars</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
