"use client"

import { useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Award, Briefcase } from "lucide-react"

const experiences = [
  {
    title: "AWS APAC Virtual Internship",
    company: "Amazon Web Services (Forage)",
    period: "2024",
    type: "Virtual Internship",
    description:
      "Completed comprehensive AWS cloud computing program focusing on cloud architecture, deployment strategies, and scalable solutions.",
    skills: ["AWS", "Cloud Computing", "DevOps", "Infrastructure"],
    icon: <Briefcase className="h-5 w-5" />,
  },
  {
    title: "Data Science Virtual Program",
    company: "Various Platforms",
    period: "2023-2024",
    type: "Professional Development",
    description:
      "Intensive data science training covering machine learning algorithms, statistical analysis, and data visualization techniques.",
    skills: ["Python", "Machine Learning", "Statistics", "Data Analysis"],
    icon: <Briefcase className="h-5 w-5" />,
  },
  {
    title: "Software Engineering Virtual Program",
    company: "Tech Industry Leaders",
    period: "2023",
    type: "Professional Development",
    description:
      "Comprehensive software engineering program covering full-stack development, system design, and best practices.",
    skills: ["Full Stack", "System Design", "Agile", "Testing"],
    icon: <Briefcase className="h-5 w-5" />,
  },
  {
    title: "National Level Athlete - Silver Medal",
    company: "200m Sprint",
    period: "Ongoing",
    type: "Athletic Achievement",
    description:
      "Achieved silver medal in 200m sprint at national level, demonstrating discipline, perseverance, and peak performance under pressure.",
    skills: ["Leadership", "Discipline", "Performance", "Teamwork"],
    icon: <Award className="h-5 w-5" />,
  },
]

export function ExperienceSection() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section id="experience" ref={sectionRef} className="py-20 px-4 sm:px-6 lg:px-8 bg-card/20">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-4xl sm:text-5xl font-bold text-center mb-12 text-gradient">Experience & Achievements</h2>

        <div className="space-y-6">
          {experiences.map((experience, index) => (
            <Card
              key={experience.title}
              className="glassmorphism border-border/50 hover:neon-glow transition-all duration-300 hover:scale-[1.02]"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-primary/20 text-primary">{experience.icon}</div>
                    <div>
                      <CardTitle className="text-xl text-primary">{experience.title}</CardTitle>
                      <CardDescription className="text-muted-foreground">{experience.company}</CardDescription>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="flex items-center gap-1 text-sm text-muted-foreground mb-1">
                      <Calendar className="h-4 w-4" />
                      {experience.period}
                    </div>
                    <Badge variant="secondary" className="glassmorphism border-border/50">
                      {experience.type}
                    </Badge>
                  </div>
                </div>
              </CardHeader>

              <CardContent>
                <p className="text-muted-foreground mb-4 text-pretty">{experience.description}</p>

                <div className="flex flex-wrap gap-2">
                  {experience.skills.map((skill) => (
                    <Badge key={skill} variant="outline" className="text-xs glassmorphism border-border/50">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
