"use client"

import { useEffect, useRef } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

const skillCategories = [
  {
    title: "Programming Languages",
    skills: [
      { name: "Python", level: 90, logo: "🐍" },
      { name: "JavaScript", level: 85, logo: "🟨" },
      { name: "Java", level: 80, logo: "☕" },
      { name: "C++", level: 75, logo: "⚡" },
    ],
  },
  {
    title: "Frontend Development",
    skills: [
      { name: "React.js", level: 90, logo: "⚛️" },
      { name: "HTML/CSS", level: 95, logo: "🌐" },
      { name: "Tailwind CSS", level: 85, logo: "🎨" },
      { name: "Next.js", level: 80, logo: "▲" },
    ],
  },
  {
    title: "Backend Development",
    skills: [
      { name: "Node.js", level: 85, logo: "🟢" },
      { name: "Express.js", level: 80, logo: "🚀" },
      { name: "MongoDB", level: 75, logo: "🍃" },
      { name: "SQL", level: 70, logo: "🗄️" },
    ],
  },
  {
    title: "AI/ML & Data Science",
    skills: [
      { name: "Machine Learning", level: 85, logo: "🤖" },
      { name: "NLP", level: 80, logo: "💬" },
      { name: "Pandas", level: 85, logo: "🐼" },
      { name: "Power BI", level: 75, logo: "📊" },
    ],
  },
]

const tools = [
  { name: "Git", emoji: "📝" },
  { name: "GitHub", emoji: "🐙" },
  { name: "VS Code", emoji: "💻" },
  { name: "Jupyter", emoji: "📓" },
  { name: "Excel", emoji: "📈" },
  { name: "OpenAI API", emoji: "🧠" },
  { name: "AWS", emoji: "☁️" },
  { name: "Vercel", emoji: "▲" },
  { name: "Netlify", emoji: "🌐" },
]

export function SkillsSection() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section id="skills" ref={sectionRef} className="py-20 px-4 sm:px-6 lg:px-8 bg-card/20">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl sm:text-5xl font-bold text-center mb-12 text-gradient">Skills & Expertise</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {skillCategories.map((category, index) => (
            <Card
              key={category.title}
              className="glassmorphism border-border/50 p-6 hover:neon-glow transition-all duration-300"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <h3 className="text-xl font-semibold mb-4 text-primary">{category.title}</h3>

              <div className="space-y-4">
                {category.skills.map((skill) => (
                  <div key={skill.name}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium flex items-center gap-2">
                        <span className="text-lg">{skill.logo}</span>
                        {skill.name}
                      </span>
                      <span className="text-sm text-muted-foreground">{skill.level}%</span>
                    </div>
                    <Progress value={skill.level} className="h-2" />
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>

        <Card className="glassmorphism border-border/50 p-6 hover:neon-glow transition-all duration-300">
          <h3 className="text-xl font-semibold mb-4 text-primary text-center">Tools & Technologies</h3>

          <div className="flex flex-wrap justify-center gap-3">
            {tools.map((tool, index) => (
              <Badge
                key={tool.name}
                variant="secondary"
                className="px-3 py-1 text-sm glassmorphism border-border/50 hover:neon-glow transition-all duration-300 hover:scale-105 flex items-center gap-2"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <span className="text-base">{tool.emoji}</span>
                {tool.name}
              </Badge>
            ))}
          </div>
        </Card>
      </div>
    </section>
  )
}
