"use client"

import { useEffect, useRef } from "react"
import { Card } from "@/components/ui/card"

export function AboutSection() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section id="about" ref={sectionRef} className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-4xl sm:text-5xl font-bold text-center mb-12 text-gradient">About Me</h2>

        <Card className="glassmorphism border-border/50 p-8 hover:neon-glow transition-all duration-300">
          <div className="text-center">
            <div className="w-32 h-32 mx-auto mb-8 rounded-full bg-gradient-to-r from-primary to-secondary animate-float flex items-center justify-center">
              <span className="text-4xl font-bold text-primary-foreground">YPS</span>
            </div>

            <p className="text-lg sm:text-xl text-muted-foreground mb-6 text-pretty">
              I'm a passionate Full Stack Developer and AI/ML Enthusiast with a strong foundation in modern web
              technologies and artificial intelligence. My journey in technology is driven by an innovation-focused
              mindset and a desire to create solutions that make a real impact.
            </p>

            <p className="text-lg sm:text-xl text-muted-foreground mb-6 text-pretty">
              With expertise spanning from frontend frameworks like React.js to backend technologies like Node.js and
              Express, combined with AI/ML capabilities using Python and various machine learning libraries, I bring a
              comprehensive approach to software development.
            </p>

            <p className="text-lg sm:text-xl text-muted-foreground text-pretty">
              Beyond coding, I'm a national-level athlete with a silver medal in 200m, which has taught me discipline,
              perseverance, and the importance of continuous improvement - qualities I bring to every project I work on.
            </p>
          </div>
        </Card>
      </div>
    </section>
  )
}
