"use client"

import { useEffect, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const toolCategories = [
  {
    category: "Frontend Development",
    icon: "🎨",
    tools: [
      { name: "React", icon: "⚛️", level: "Expert" },
      { name: "Next.js", icon: "▲", level: "Expert" },
      { name: "TypeScript", icon: "📘", level: "Advanced" },
      { name: "Tailwind CSS", icon: "🎨", level: "Expert" },
      { name: "HTML5", icon: "🌐", level: "Expert" },
      { name: "CSS3", icon: "🎨", level: "Expert" },
      { name: "JavaScript", icon: "💛", level: "Expert" },
      { name: "Three.js", icon: "🎮", level: "Intermediate" },
    ],
  },
  {
    category: "Backend Development",
    icon: "⚙️",
    tools: [
      { name: "Node.js", icon: "💚", level: "Advanced" },
      { name: "Express.js", icon: "🚀", level: "Advanced" },
      { name: "Python", icon: "🐍", level: "Expert" },
      { name: "Django", icon: "🎯", level: "Advanced" },
      { name: "FastAPI", icon: "⚡", level: "Intermediate" },
      { name: "RESTful APIs", icon: "🔗", level: "Expert" },
      { name: "GraphQL", icon: "📊", level: "Intermediate" },
    ],
  },
  {
    category: "AI/ML & Data Science",
    icon: "🤖",
    tools: [
      { name: "TensorFlow", icon: "🧠", level: "Advanced" },
      { name: "PyTorch", icon: "🔥", level: "Advanced" },
      { name: "Scikit-learn", icon: "📈", level: "Expert" },
      { name: "Pandas", icon: "🐼", level: "Expert" },
      { name: "NumPy", icon: "🔢", level: "Expert" },
      { name: "OpenAI API", icon: "🤖", level: "Advanced" },
      { name: "Hugging Face", icon: "🤗", level: "Intermediate" },
      { name: "Computer Vision", icon: "👁️", level: "Advanced" },
    ],
  },
  {
    category: "Databases",
    icon: "🗄️",
    tools: [
      { name: "MongoDB", icon: "🍃", level: "Advanced" },
      { name: "PostgreSQL", icon: "🐘", level: "Advanced" },
      { name: "MySQL", icon: "🐬", level: "Advanced" },
      { name: "Firebase", icon: "🔥", level: "Advanced" },
      { name: "Redis", icon: "🔴", level: "Intermediate" },
      { name: "Supabase", icon: "⚡", level: "Intermediate" },
    ],
  },
  {
    category: "Cloud & DevOps",
    icon: "☁️",
    tools: [
      { name: "AWS", icon: "☁️", level: "Intermediate" },
      { name: "Google Cloud", icon: "🌤️", level: "Intermediate" },
      { name: "Docker", icon: "🐳", level: "Advanced" },
      { name: "Git", icon: "📝", level: "Expert" },
      { name: "GitHub", icon: "🐙", level: "Expert" },
      { name: "Vercel", icon: "▲", level: "Advanced" },
      { name: "Netlify", icon: "🌐", level: "Advanced" },
    ],
  },
  {
    category: "Design & Tools",
    icon: "🎨",
    tools: [
      { name: "Figma", icon: "🎨", level: "Advanced" },
      { name: "Adobe XD", icon: "🎯", level: "Intermediate" },
      { name: "Photoshop", icon: "🖼️", level: "Intermediate" },
      { name: "VS Code", icon: "💻", level: "Expert" },
      { name: "Postman", icon: "📮", level: "Advanced" },
      { name: "Jupyter", icon: "📓", level: "Advanced" },
    ],
  },
]

const getLevelColor = (level: string) => {
  switch (level) {
    case "Expert":
      return "bg-gradient-to-r from-green-500 to-emerald-500"
    case "Advanced":
      return "bg-gradient-to-r from-blue-500 to-cyan-500"
    case "Intermediate":
      return "bg-gradient-to-r from-yellow-500 to-orange-500"
    default:
      return "bg-gradient-to-r from-gray-500 to-slate-500"
  }
}

export function ToolsSection() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section
      id="tools"
      ref={sectionRef}
      className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-background to-background/50"
    >
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl sm:text-5xl font-bold mb-4 text-gradient">Tools & Technologies</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            A comprehensive arsenal of cutting-edge technologies and tools I use to build exceptional digital
            experiences
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {toolCategories.map((category, categoryIndex) => (
            <Card
              key={category.category}
              className="glassmorphism border-border/50 hover:neon-glow transition-all duration-300 hover:scale-105 group"
              style={{ animationDelay: `${categoryIndex * 0.1}s` }}
            >
              <CardHeader className="text-center">
                <div className="text-4xl mb-2">{category.icon}</div>
                <CardTitle className="text-xl text-primary">{category.category}</CardTitle>
              </CardHeader>

              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  {category.tools.map((tool, toolIndex) => (
                    <div
                      key={tool.name}
                      className="flex flex-col items-center p-3 rounded-lg glassmorphism border-border/30 hover:border-primary/50 transition-all duration-300 group/tool"
                      style={{ animationDelay: `${categoryIndex * 0.1 + toolIndex * 0.05}s` }}
                    >
                      <div className="text-2xl mb-1 group-hover/tool:scale-110 transition-transform duration-300">
                        {tool.icon}
                      </div>
                      <div className="text-sm font-medium text-center mb-1">{tool.name}</div>
                      <Badge className={`text-xs px-2 py-1 text-white border-0 ${getLevelColor(tool.level)}`}>
                        {tool.level}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16 text-center">
          <div className="inline-flex items-center gap-4 px-8 py-4 glassmorphism border-border/50 rounded-full">
            <span className="text-lg font-semibold text-primary">Total Technologies:</span>
            <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white text-lg px-4 py-2">
              {toolCategories.reduce((total, category) => total + category.tools.length, 0)}+
            </Badge>
          </div>
        </div>
      </div>
    </section>
  )
}
