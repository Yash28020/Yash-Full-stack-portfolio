"use client"

import { useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Award, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"

const certifications = [
  {
    title: "BA Data Science Certification",
    issuer: "Professional Institution",
    year: "2024",
    description:
      "Comprehensive data science program covering statistical analysis, machine learning, and data visualization.",
    skills: ["Data Science", "Statistics", "Python", "Machine Learning"],
    credentialUrl: "#",
  },
  {
    title: "JPMorgan Software Engineering",
    issuer: "JPMorgan Chase & Co.",
    year: "2024",
    description: "Virtual experience program focusing on software engineering practices in financial technology.",
    skills: ["Software Engineering", "Financial Tech", "Java", "System Design"],
    credentialUrl: "#",
  },
  {
    title: "OneRoadmap Data Analytics",
    issuer: "OneRoadmap",
    year: "2023",
    description:
      "Advanced data analytics certification covering business intelligence and data-driven decision making.",
    skills: ["Data Analytics", "Business Intelligence", "SQL", "Visualization"],
    credentialUrl: "#",
  },
  {
    title: "FreeCodeCamp Responsive Web Design",
    issuer: "FreeCodeCamp",
    year: "2023",
    description: "Comprehensive web development certification focusing on responsive design principles and modern CSS.",
    skills: ["HTML", "CSS", "Responsive Design", "Web Development"],
    credentialUrl: "#",
  },
  {
    title: "Google Networking Fundamentals",
    issuer: "Google (Coursera)",
    year: "2023",
    description: "Professional certificate covering networking concepts, protocols, and cloud infrastructure.",
    skills: ["Networking", "Cloud Computing", "Infrastructure", "Security"],
    credentialUrl: "#",
  },
]

export function CertificationsSection() {
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 },
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section id="certifications" ref={sectionRef} className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl sm:text-5xl font-bold text-center mb-12 text-gradient">Certifications & Credentials</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {certifications.map((cert, index) => (
            <Card
              key={cert.title}
              className="glassmorphism border-border/50 hover:neon-glow transition-all duration-300 hover:scale-105 group"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 rounded-lg bg-primary/20 text-primary">
                    <Award className="h-5 w-5" />
                  </div>
                  <Badge variant="secondary" className="glassmorphism border-border/50">
                    {cert.year}
                  </Badge>
                </div>

                <CardTitle className="text-lg text-primary group-hover:text-secondary transition-colors duration-300">
                  {cert.title}
                </CardTitle>

                <CardDescription className="text-muted-foreground">{cert.issuer}</CardDescription>
              </CardHeader>

              <CardContent>
                <p className="text-sm text-muted-foreground mb-4 text-pretty">{cert.description}</p>

                <div className="flex flex-wrap gap-2 mb-4">
                  {cert.skills.map((skill) => (
                    <Badge key={skill} variant="outline" className="text-xs glassmorphism border-border/50">
                      {skill}
                    </Badge>
                  ))}
                </div>

                <Button
                  size="sm"
                  variant="outline"
                  className="w-full glassmorphism border-border/50 hover:neon-glow bg-transparent"
                  asChild
                >
                  <a href={cert.credentialUrl} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    View Credential
                  </a>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
