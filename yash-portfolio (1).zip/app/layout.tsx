import type React from "react"
import type { Metadata } from "next"
import { GeistSans } from "geist/font/sans"
import { GeistMono } from "geist/font/mono"
import { Analytics } from "@vercel/analytics/next"
import { Suspense } from "react"
import "./globals.css"

export const metadata: Metadata = {
  title: "Yash Pratap Singh - Full Stack Developer & AI/ML Enthusiast",
  description:
    "Passionate Full Stack Developer & AI/ML Enthusiast dedicated to creating intelligent systems, data-driven apps, and immersive UIs that bring innovation to the world.",
  generator: "v0.app",
  keywords: ["Full Stack Developer", "AI/ML", "React", "Node.js", "Python", "Machine Learning"],
  authors: [{ name: "Yash Pratap Singh" }],
  openGraph: {
    title: "Yash Pratap Singh - Full Stack Developer & AI/ML Enthusiast",
    description: "Creating intelligent systems and immersive digital experiences",
    type: "website",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="dark">
      <body className={`font-sans ${GeistSans.variable} ${GeistMono.variable} antialiased`}>
        <Suspense fallback={null}>{children}</Suspense>
        <Analytics />
      </body>
    </html>
  )
}
